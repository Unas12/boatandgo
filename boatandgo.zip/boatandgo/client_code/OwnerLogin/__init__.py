from ._anvil_designer import OwnerLoginTemplate
from anvil import *

# PIN code — change this to whatever your team wants
OWNER_PIN = "1234"

class OwnerLogin(OwnerLoginTemplate):
    def __init__(self, **properties):
        self.init_components(**properties)

    def btn_login_click(self, **event_args):
        entered = self.txt_pin.text.strip()
        if entered == OWNER_PIN:
            self.lbl_error.visible = False
            open_form('OwnerDashboard')
        else:
            self.lbl_error.text = "❌ Incorrect PIN. Please try again."
            self.lbl_error.visible = True
            self.txt_pin.text = ""

    def btn_back_click(self, **event_args):
        open_form('HomeScreen')
