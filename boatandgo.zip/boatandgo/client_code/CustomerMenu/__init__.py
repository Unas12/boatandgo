from ._anvil_designer import CustomerMenuTemplate
from anvil import *

# Menu items data
MENU_ITEMS = [
    {"name": "Classic Boat Noodle 🍜",     "description": "Pork blood broth, pork slices, morning glory",      "price": "฿55"},
    {"name": "Beef Boat Noodle 🥩",        "description": "Beef bone broth, beef slices, bean sprouts",        "price": "฿65"},
    {"name": "Chicken Tom Yum 🍗",         "description": "Spicy lemongrass broth, chicken, mushrooms",        "price": "฿60"},
    {"name": "Vegetarian Clear Broth 🥬",  "description": "Vegetable broth, tofu, mixed mushrooms",            "price": "฿50"},
]

class CustomerMenu(CustomerMenuTemplate):
    def __init__(self, **properties):
        self.init_components(**properties)
        self.data_grid_menu.items = MENU_ITEMS

    def btn_order_now_click(self, **event_args):
        open_form('CustomerOrder')

    def btn_back_click(self, **event_args):
        open_form('HomeScreen')
