from ._anvil_designer import CustomerOrderTemplate
from anvil import *
import anvil.server

class CustomerOrder(CustomerOrderTemplate):
    def __init__(self, **properties):
        self.init_components(**properties)

    def btn_confirm_click(self, **event_args):
        # Validate inputs
        if not self.txt_name.text.strip():
            alert("Please enter your name.")
            return
        if not self.txt_phone.text.strip():
            alert("Please enter your phone number.")
            return

        # Build order summary to pass to status page
        order = {
            "name":     self.txt_name.text.strip(),
            "phone":    self.txt_phone.text.strip(),
            "noodle":   self.dd_noodle.selected_value,
            "spice":    self.dd_spice.selected_value,
            "pickup":   self.dd_pickup.selected_value,
            "cutlery":  self.dd_cutlery.selected_value,
            "payment":  self.dd_payment.selected_value,
            "requests": self.txt_requests.text.strip(),
        }
        open_form('CustomerStatus', order=order)

    def btn_back_click(self, **event_args):
        open_form('CustomerMenu')
