from ._anvil_designer import OwnerDashboardTemplate
from anvil import *
from datetime import date

# Sample order data — in a real app this would come from a database
SAMPLE_ORDERS = [
    {"order_id": "#B-041", "name": "Somchai",  "item": "Classic Boat Noodle", "pickup": "11:30 AM", "status": "✅ Ready"},
    {"order_id": "#B-042", "name": "Nattaya",  "item": "Beef Boat Noodle",    "pickup": "12:00 PM", "status": "👨‍🍳 Preparing"},
    {"order_id": "#B-043", "name": "Piyawat",  "item": "Chicken Tom Yum",     "pickup": "12:00 PM", "status": "👨‍🍳 Preparing"},
    {"order_id": "#B-044", "name": "Sirima",   "item": "Vegetarian Broth",    "pickup": "12:30 PM", "status": "📋 Received"},
    {"order_id": "#B-045", "name": "Tanakorn", "item": "Classic Boat Noodle", "pickup": "12:30 PM", "status": "📋 Received"},
    {"order_id": "#B-046", "name": "Monrudee", "item": "Beef Boat Noodle",    "pickup": "1:00 PM",  "status": "📋 Received"},
]

class OwnerDashboard(OwnerDashboardTemplate):
    def __init__(self, **properties):
        self.init_components(**properties)

        # Show today's date in the corner
        today = date.today().strftime("%A, %d %B %Y")
        self.lbl_date.text = f"📅 {today}"

        # Load sample orders into the grid
        self.data_grid_orders.items = SAMPLE_ORDERS

    def btn_logout_click(self, **event_args):
        open_form('HomeScreen')
