from ._anvil_designer import CustomerStatusTemplate
from anvil import *
import random

class CustomerStatus(CustomerStatusTemplate):
    def __init__(self, order=None, **properties):
        self.init_components(**properties)
        self.order = order or {}

        # Generate a random order ID
        order_id = random.randint(100, 999)
        self.lbl_order_id.text = f"Order #B-{order_id}"

        # Set payment status badge
        payment = self.order.get("payment", "Cash at Counter")
        if "PromptPay" in payment or "Credit" in payment:
            self.lbl_payment_status.text = "✅ PAID"
            self.lbl_payment_status.foreground = "#27AE60"
        else:
            self.lbl_payment_status.text = "💵 CASH — Pay at Counter"
            self.lbl_payment_status.foreground = "#C0392B"

        # Build order summary text
        if self.order:
            summary = (
                f"Name: {self.order.get('name', '-')}\n"
                f"Phone: {self.order.get('phone', '-')}\n"
                f"Noodle: {self.order.get('noodle', '-')}\n"
                f"Spice: {self.order.get('spice', '-')}\n"
                f"Pickup: {self.order.get('pickup', '-')}\n"
                f"Cutlery: {self.order.get('cutlery', '-')}\n"
                f"Payment: {self.order.get('payment', '-')}\n"
            )
            requests = self.order.get('requests', '').strip()
            if requests:
                summary += f"Special Requests: {requests}"
            self.lbl_summary.text = summary

        # Current stage — stage 2 is active by default (kitchen preparing)
        # Stage 1 = green (done), Stage 2 = gold (active), Stage 3 = grey (waiting)
        self.lbl_stage1.foreground = "#27AE60"
        self.lbl_stage2.foreground = "#D4A017"
        self.lbl_stage3.foreground = "#BBBBBB"
        self.lbl_stage3_desc.foreground = "#BBBBBB"

    def btn_save_qr_click(self, **event_args):
        alert("📲 QR Code saved! (In the full app, this would download the QR image to your device.)")

    def btn_email_qr_click(self, **event_args):
        alert("📧 QR Code emailed! (In the full app, this would send the QR to your email address.)")

    def btn_home_click(self, **event_args):
        open_form('HomeScreen')
